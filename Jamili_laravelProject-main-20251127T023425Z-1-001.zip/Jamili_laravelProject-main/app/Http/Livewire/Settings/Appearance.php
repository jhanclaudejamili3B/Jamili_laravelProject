<?php
namespace App\Http\Livewire\Settings;

use Livewire\Component;

class Appearance extends Component
{
    public function render()
    {
        return view('livewire.settings.appearance');
    }
}
